#include <iostream>
#include <random>
#include <chrono>
#include <ctime>
#include <vector>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>

//定义x和y方向格数，总步数计数
int x_num=0;
int y_num=0;
int z_num=0;
int count=0;

//定义空间参数
double x_sep=0;
double y_sep=0;
double z_sep=0;
int x_tot=100;
int y_tot=100;
int z_tot=20;

//定义物理参数
float k=1;
float eta=1;

//定义工作
int particle_num=15930;
int test_particle_num=100;
std::string filename="1006";

//定义物理世界
std::vector<float> radius={1,1.4};
std::vector<float> test_radius={0.1,0.3,1,2,3};
float max_r=3;
int balance_max=1e4;
int random_seed=std::stoi(filename);
std::mt19937 gen(random_seed);
std::random_device rd;

//建立一个求余函数
int m(int a,int b){
    if (a>=b){
        a-=b;
    }
    if (a>=b){
        a-=b;
    }
    if (a<0){
        a+=b;
    }
    if (a<0){
        a+=b;
    }
    return a;
}

double mm(double a,double b){
    while (a>b){
        a-=b;
    } 
    while (a<0){
        a+=b;
    }
    return a;
}

//粒子类
class Particle{
public:
    float r;
    double x;
    double y;
    double z;

    int id;
    int x_cell;
    int y_cell;
    int z_cell;

    Particle():r(0),x(0),y(0),z(0),id(0){}
    Particle(float radius,double particle_x,double particle_y,double particle_z,int particle_id)
        :r(radius),x(particle_x),y(particle_y),z(particle_z),id(particle_id){

    x_cell=x/x_sep;
    y_cell=y/y_sep;
    z_cell=z/z_sep;
    }
};

//创造随机初始世界
std::vector<std::vector<std::vector<std::vector<Particle>>>> generate_world() {
    double cell=2*max_r+0.1;
    x_num=x_tot/cell;
    y_num=y_tot/cell;
    z_num=z_tot/cell;
    x_sep=x_tot/double(x_num);
    y_sep=y_tot/double(y_num);
    z_sep=z_tot/double(z_num);
    std::uniform_real_distribution<double> dis(0.0, 1.0);
    std::vector<std::vector<std::vector<std::vector<Particle>>>> savings(x_num, std::vector<std::vector<std::vector<Particle>>>(y_num, std::vector<std::vector<Particle>>(z_num,std::vector<Particle>())));
    for (int i=0;i<particle_num;++i) {
        int choose_id=i%2;
        float r_i=radius[choose_id];
        double random_num=0;
        random_num=dis(gen);
        double x_i=x_tot*random_num;
        random_num=dis(gen);
        double y_i=y_tot*random_num;
        random_num=dis(gen);
        double z_i=z_tot*random_num;
        Particle particle_i(r_i,x_i,y_i,z_i,5*test_particle_num+i);
        savings[particle_i.x_cell][particle_i.y_cell][particle_i.z_cell].push_back(particle_i);
    }
    for (int j=0;j<5;++j){
        for (int i=0;i<test_particle_num;++i) {
            float r_i=test_radius[j];
            double random_num=0;
            random_num=dis(gen);
            double x_i=x_tot*random_num;
            random_num=dis(gen);
            double y_i=y_tot*random_num;
            random_num=dis(gen);
            double z_i=z_tot*random_num;
            Particle particle_i(r_i,x_i,y_i,z_i,i+test_particle_num*j);
            savings[particle_i.x_cell][particle_i.y_cell][particle_i.z_cell].push_back(particle_i);
        }
    }
    return savings;
}

//实例化随机初始世界
std::vector<std::vector<std::vector<std::vector<Particle>>>> savings=generate_world();

//计算一对粒子受力
std::vector<double> calculate_force(double x_self,double y_self,double z_self,double x,double y,double z,float r_self,float r,int id1,int id2){
    if (x_self-x>2*x_tot/3){
        x_self-=x_tot;
    }
    else if (x-x_self>2*x_tot/3){
        x_self+=x_tot;
    }
    if (y_self-y>2*y_tot/3){
        y_self-=y_tot;
    }
    else if (y-y_self>2*y_tot/3){
        y_self+=y_tot;
    }
    if (z_self-z>2*z_tot/3){
        z_self-=z_tot;
    }
    else if (z-z_self>2*z_tot/3){
        z_self+=z_tot;
    }
    if ((pow((x_self-x),2)+pow((y_self-y),2)+pow((z_self-z),2)>pow((r_self+r),2)) or id1==id2) {
        std::vector<double> force(3, 0);
        return force;
    }
    else{
        double delta_r=pow(pow((x_self-x),2)+pow((y_self-y),2)+pow((z_self-z),2),0.5);
        double f_tot=k*(r_self+r-delta_r);
        double fx=f_tot*(x_self-x)/delta_r;
        double fy=f_tot*(y_self-y)/delta_r;
        double fz=f_tot*(z_self-z)/delta_r;
        std::vector<double> force{fx,fy,fz};
        return force;
    }
}

//计算一对粒子能量
double calculate_energy(double x_self,double y_self,double z_self,double x,double y,double z,float r_self,float r,int id1,int id2){
    if (x_self-x>2*x_tot/3){
        x_self-=x_tot;
    }
    else if (x-x_self>2*x_tot/3){
        x_self+=x_tot;
    }
    if (y_self-y>2*y_tot/3){
        y_self-=y_tot;
    }
    else if (y-y_self>2*y_tot/3){
        y_self+=y_tot;
    }
    if (z_self-z>2*z_tot/3){
        z_self-=z_tot;
    }
    else if (z-z_self>2*z_tot/3){
        z_self+=z_tot;
    }
    if ((pow((x_self-x),2)+pow((y_self-y),2)+pow((z_self-z),2)>pow((r_self+r),2)) or id1==id2) {
        return 0;
    }
    else{
        double delta_r=pow(pow((x_self-x),2)+pow((y_self-y),2)+pow((z_self-z),2),0.5);
        double E=0.5*pow((r+r_self-delta_r),2);
        return E;
    }
}

//寻找临近受力
std::vector<double> neighbor_force(Particle p){
    double force_x=0;
    double force_y=0;
    double force_z=0;

    for (int i=-1;i<=1;++i){
        for (int j=-1;j<=1;++j){
            for (int k=-1;k<=1;++k){
                for (int l=0;l<savings[m(p.x_cell+i+x_num,x_num)][m(p.y_cell+j+y_num,y_num)][m(p.z_cell+k+z_num,z_num)].size();++l){
                    Particle p_e=savings[m(p.x_cell+i+x_num,x_num)][m(p.y_cell+j+y_num,y_num)][m(p.z_cell+k+z_num,z_num)][l];
                    std::vector<double> F_singl=calculate_force(p.x,p.y,p.z,p_e.x,p_e.y,p_e.z,p.r,p_e.r,p.id,p_e.id);
                    force_x+=F_singl[0];
                    force_y+=F_singl[1];
                    force_z+=F_singl[2];
                }
            }
        }
    }

    std::vector<double> force{force_x,force_y,force_z};
    return force;
}

//计算临近能量
double neighbor_energy(Particle p){
    double E_tot=0;
    for (int i=-1;i<=1;++i){
        for (int j=-1;j<=1;++j){
            for (int k=-1;k<=1;++k){
                for (int l=0;l<savings[m(p.x_cell+i+x_num,x_num)][m(p.y_cell+j+y_num,y_num)][m(p.z_cell+k+z_num,z_num)].size();++l){
                    Particle p_e=savings[m(p.x_cell+i+x_num,x_num)][m(p.y_cell+j+y_num,y_num)][m(p.z_cell+k+z_num,z_num)][l];
                    double E_singl=calculate_energy(p.x,p.y,p.z,p_e.x,p_e.y,p_e.z,p.r,p_e.r,p.id,p_e.id);
                    E_tot+=E_singl;
                }
            }
        }
    }
    return E_tot;
}

//计算总能量
double total_energy(){
    double Energy_total=0;
    for (int i=0;i<x_num;++i) {
        for (int j=0;j<y_num;++j) {
            for (int k=0;k<z_num;++k) {
                for (int l=0;l<savings[i][j][k].size();++l){
                    Energy_total+=neighbor_energy(savings[i][j][k][l]);
                }
            }
        }
    }
    return Energy_total;
}

//存档
void write_world(){
    std::string name=std::to_string(random_seed);
    std::ofstream outFile(filename+".txt");
    outFile<<x_tot<<" "<<y_tot<<" "<<z_tot<<" "<<particle_num<<" "<<test_particle_num<<std::endl;
    for (int i=0;i<x_num;++i) {
        for (int j=0;j<y_num;++j) {
            for (int k=0;k<z_num;++k) {
                for (int l=0;l<savings[i][j][k].size();++l){
                    Particle part=savings[i][j][k][l];
                    std::ostringstream oss;
                    oss<<std::fixed<<std::setprecision(15);
                    oss<<part.x<<" "<<part.y<<" "<<part.z<<" "<<part.r<<" "<<part.id<<std::endl;
                    outFile<<oss.str();
                }
            }
        }
    }
    outFile.close();
}

//计算MD移动
std::vector<double> move_to(double fx,double fy,double fz,Particle p,float t_step){
    std::vector<double> move{mm(fx/eta*t_step+p.x,x_tot),mm(fy/eta*t_step+p.y,y_tot),mm(fz/eta*t_step+p.z,z_tot)};
    return move;
}

//MD步进和力矩
void step_forward(float t_step){
    std::vector<std::vector<std::vector<std::vector<Particle>>>> new_savings(x_num, std::vector<std::vector<std::vector<Particle>>>(y_num, std::vector<std::vector<Particle>>(z_num,std::vector<Particle>())));
    for (int i=0;i<x_num;++i) {
        for (int j=0;j<y_num;++j) {
            for (int k=0;k<z_num;++k){
                for (int l=0;l<savings[i][j][k].size();++l){
                    Particle part_old=savings[i][j][k][l];
                    std::vector<double> force=neighbor_force(part_old);
                    std::vector<double> move=move_to(force[0],force[1],force[2],part_old,t_step);
                    Particle part_new(part_old.r,move[0],move[1],move[2],part_old.id);
                    new_savings[part_new.x_cell][part_new.y_cell][part_new.z_cell].push_back(part_new);
                }
            }
        }
    }
    savings=new_savings;
}

//读档
double read_world(){
    std::vector<std::vector<std::vector<std::vector<Particle>>>> savingss(x_num, std::vector<std::vector<std::vector<Particle>>>(y_num, std::vector<std::vector<Particle>>(z_num,std::vector<Particle>())));
    std::ifstream inFile(filename+".txt");
    std::string line;
    bool need_phys_param=true;
    double L=0;
    count=0;
    while (std::getline(inFile, line)) {
            if (need_phys_param){
                std::istringstream iss(line);
                std::string word;
                std::vector<std::string> words;
                while (iss >> word) {
                    words.push_back(word);
                }
                x_tot=std::stoi(words[0]);
                y_tot=std::stoi(words[1]);
                z_tot=std::stoi(words[2]);
                need_phys_param=false;
                double cell=2*max_r+0.1;
                x_num=x_tot/cell;
                y_num=y_tot/cell;
                x_sep=x_tot/double(x_num);
                y_sep=y_tot/double(y_num);
            }
            else{
                std::istringstream iss(line);
                std::string word;
                std::vector<std::string> words;
                while (iss >> word) {
                    words.push_back(word);
                }
                count+=1;
                double x=std::stod(words[0]);
                double y=std::stod(words[1]);
                double z=std::stod(words[2]);
                double r=std::stod(words[3]);
                int id=std::stoi(words[4]);
                Particle particle_i(r,x,y,z,id);
                savingss[particle_i.x_cell][particle_i.y_cell][particle_i.z_cell].push_back(particle_i);
            }
    }
    savings=savingss;
    return L;
}

//开始计算
int main(){
    std::cout<<filename<<" "<<particle_num<<std::endl;
    double E_old=1e10;
    double E_new=1e9;
    for (int i=0;i<1e4;i++){
        E_old=E_new;
        step_forward(1e-2);
        E_new=total_energy();
        std::cout<<E_new<<" "<<std::endl;
        write_world();
    }

    
}


